package com.zetcode;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;

public class Chess extends JFrame {

    public Chess() {
        
        initUI();
        
    }
    
    private void initUI() {

        add(new Board());
        setResizable(false);
        pack();
        
        setTitle("Chinese Chess");
        setLocationRelativeTo(null);        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

            

    public static void main(String[] args) {
        
        EventQueue.invokeLater(() -> {
            Chess ex = new Chess();
            ex.setVisible(true);
        });
    }
}